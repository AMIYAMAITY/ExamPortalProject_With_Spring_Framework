package com.examportal.customvalidation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author amiya
 */
class CustomDateValidation implements ConstraintValidator<CusDate, String> {

    @Override
    public void initialize(CusDate a) {
    }

    @Override
    public boolean isValid(String d, ConstraintValidatorContext cvc) {
  
      SimpleDateFormat adf = new SimpleDateFormat("yyyy-MM-dd");
      DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        Date todayDate=new Date();
        try {
            Date   usrDate = adf.parse(d);
            int mm=usrDate.getMonth();
            int dd=usrDate.getDate();
            
            if( (0<= mm && mm <=11) && (1<= dd && dd<=31) && usrDate.after(todayDate))
                return true;
        } catch (ParseException ex) {
           return false;
        }
        return false;
    }

}
