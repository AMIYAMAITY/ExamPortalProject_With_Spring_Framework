package com.examportal.customvalidation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author amiya
 */
class CustomTimeValidation implements ConstraintValidator<CusTime, String> {

    @Override
    public void initialize(CusTime a) {
    }

    @Override
    public boolean isValid(String t, ConstraintValidatorContext cvc) {

        if (t != null) {
            if (!t.isEmpty() && t.contains(":")) {
                String time[] = t.split(":");
                String sh = time[0];
                String sm = time[1];
                if (!sh.isEmpty() && !sm.isEmpty()) {
                    int h = Integer.parseInt(sh);
                    int m = Integer.parseInt(sm);
                    if ((00 <= h && h <= 23) && (00 <= m && m <= 59)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}
