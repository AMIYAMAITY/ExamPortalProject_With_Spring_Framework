
package com.examportal.customvalidation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author amiya
 */
class CustomAnswerOptionValidation implements ConstraintValidator<CusOption, String> 
{

    @Override
    public void initialize(CusOption a) {}

    @Override
    public boolean isValid(String t, ConstraintValidatorContext cvc) {
        if(t.equals('A') || t.equals('B') || t.equals('C') || t.equals('D') )
            return true;
        else
        return false;
    }
    
}
