
package com.examportal.userservice;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 *
 * @author amiya
 */
public class UserSignup 
{
    @NotEmpty(message = "Data Required")
    @Size(min = 1,max = 20,message = "Input size must be 20 character")
    private String name;
    @NotEmpty(message = "Data Required")
    @Size(min = 10,max = 128,message = "Input size must be 127 character")
    @Email(message = "Invalid Email ID")
   private String email;
    @NotEmpty(message = "Data Required")
    @Size(min = 10,max = 10,message = "Input size must be 10 character")
    private String roll;
    @NotEmpty(message = "Data Required")
    @Size(min = 1,max = 8,message = "Input size must be 8 character")
    private String gender;
    @NotEmpty(message = "Data Required")
    @Size(min = 5,max = 20,message = "Input size must be 20 character")
   private String pass;
    private int uid;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
    
    
}
