package com.examportal.userservice;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 *
 * @author amiya
 */
public class UserUpdateProfile {

    @NotEmpty(message = "Data Required")
    @Email(message = "Invalid Email ID")
    private String email;
    @NotEmpty(message = "Data Required")
    @Size(min = 5, max = 10, message = "Input size must be in between 5 to 10 character")
    private String pass1;
    @NotEmpty(message = "Data Required")
    @Size(min = 5, max = 10, message = "Input size must be in between 5 to 10 character")
    private String pass2;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass1() {
        return pass1;
    }

    public void setPass1(String pass1) {
        this.pass1 = pass1;
    }

    public String getPass2() {
        return pass2;
    }

    public void setPass2(String pass2) {
        this.pass2 = pass2;
        if (!pass1.equals(this.pass2)) {
            this.pass1 = null;
        }
    }

}
