/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.examportal.timemanagement;

import com.examportal.controller.UserController;
import com.examportal.controller.WebController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author amiya
 */
public class TimeThread  extends Thread {
   private HttpServletRequest rq;
    private  int i;

    public TimeThread(HttpServletRequest req)
    {
        this.rq=req;
    }
    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    @Override
    public void run() {
        boolean b=true;
        while (b) {
            try {
                Thread.sleep(1000);
                i = i - 1;
                if(i<=0)
                {
//                    HttpSession session=rq.getSession();
//                    session.setAttribute("userid", null);
                    b=false;
                }
            } catch (InterruptedException ex) {
                    
            } 
        }

    }
}