
package com.examportal.timemanagement;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author amiya
 */
public class DateTimeManagement 
{ 
      public boolean checkTime(String st,String et,String nt)
    {
         Date    ts=null;
        Date    te=null;
        Date    tn=null;
           SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        try {
                ts = format.parse(st);
                te = format.parse(et);
                tn = format.parse(nt);
                
               if(ts.getTime() <= tn.getTime() && tn.getTime() <=te.getTime())
                   return true;
                
        } catch (Exception ex) {
           return false;
        }
        return false;
    }
}
