
package com.examportal.timemanagement;

import java.text.SimpleDateFormat;
import java.util.Date;


/**
 *
 * @author amiya
 */
public class TimeManageMent
{
 
    public Integer getMinutesWithString(String st,String et)
    {
        
        Date    t1=null;
        Date    t2=null;
           SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        try {
                t1 = format.parse(st);
                t2 = format.parse(et);
                long diff = t2.getTime() - t1.getTime();
                if(t2.getTime() < t1.getTime())
                    return 0;

			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;

                        int minutes=(int)(diffHours*60+diffMinutes);
                        return minutes;
        } catch (Exception ex) {
           return 0;
        }

    } 
}
