
package com.examportal.superadmin.database;

import com.examportal.superadmin.SuperAdminUpdateProfile;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class SuperAdminUpdateRowMapper implements RowMapper<SuperAdminUpdateProfile>{

    @Override
    public SuperAdminUpdateProfile mapRow(ResultSet rs, int i) throws SQLException {
       SuperAdminUpdateProfile saup=new SuperAdminUpdateProfile();
       saup.setId(rs.getInt("id"));
       saup.setEmail(rs.getString("email"));
       saup.setPass(rs.getString("pass"));
       saup.setUname(rs.getString("uname"));
       return saup;
    }
    
}
