
package com.examportal.superadmin.database;

import com.examportal.superadmin.SuperAdminUpdateProfile;


/**
 *
 * @author amiya
 */
public interface SuperAdminLoginDAO 
{
    public int checkLogin(String uname,String pass);
    public SuperAdminUpdateProfile getData(Integer id);
    public boolean updateProfile(String email,String pass,Integer id);
    
}
