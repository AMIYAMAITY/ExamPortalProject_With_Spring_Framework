
package com.examportal.superadmin.database;


import com.examportal.database.DatabaseConfig;
import com.examportal.superadmin.SuperAdminUpdateProfile;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author amiya
 */
public class SuperAdminJdbcTemplate implements SuperAdminLoginDAO
{

     private DataSource dataSource;
    private JdbcTemplate jdt;
    
    public SuperAdminJdbcTemplate()
    {
         DatabaseConfig dbc=new DatabaseConfig();
         this.dataSource = dbc.getDataSource();
          this.jdt = new JdbcTemplate(this.dataSource);
    }
    @Override
    public int checkLogin(String email, String pass) {
        String SQL="select id from SUPER_ADMIN where email=? and pass=?";
         try {
            int id = jdt.queryForInt(SQL,email,pass);
            return id;
        } catch (Exception ex) {
            return 0;
        }
    }

    @Override
    public SuperAdminUpdateProfile getData(Integer id) {
        String SQL="SELECT * FROM SUPER_ADMIN WHERE id=?";
        try
        {
        SuperAdminUpdateProfile saup=jdt.queryForObject(SQL, new Object[]{id},new SuperAdminUpdateRowMapper());
        return saup;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    @Override
    public boolean updateProfile(String email,String pass,Integer id) {
         String SQL ="update SUPER_ADMIN set email=?,pass=? where id=?";
          try
        {
       int r=jdt.update(SQL,email,pass,id );
       if(r!=0)
           return true;
       else
           return false;
        }
            catch(Exception ex)
        {
            return false;
        }
       
    }
    
    


   
    
}
