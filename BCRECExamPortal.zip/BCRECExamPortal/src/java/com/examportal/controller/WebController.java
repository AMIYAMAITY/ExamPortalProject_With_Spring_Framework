package com.examportal.controller;

import com.examportal.adminservice.AdminLogin;
import com.examportal.adminservice.AdminRequest;
import com.examportal.adminservice.AdminRequest2;
import com.examportal.adminservice.Question;
import com.examportal.adminservice.QuestionSetName;
import com.examportal.database.AdminSignupJDBCTemplate;
import com.examportal.database.QuestionJDBCTemplate;
import com.examportal.database.QuestionSetNameJdbcTemplate;
import com.examportal.database.ReferralKeyJdbcTemplate;
import com.examportal.database.user.AnswerSubmitJDBCTemplate;
import com.examportal.email.SendMailTLS;
import com.examportal.security.AES;
import com.examportal.service.RandomString;
import com.examportal.userservice.UserUpdateProfile;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author amiya
 */
@Controller
@RequestMapping("/admin")
public class WebController {

    @RequestMapping(method = RequestMethod.GET)
    public String indexAdmin(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            return "redirect:/admin/adquestionindex";
        } else {
            return "adminlogin";
        }
    }

    @RequestMapping(value = "adminlogin", method = RequestMethod.POST)
    public ModelAndView adminLogin(@Valid @ModelAttribute("adlogin") AdminLogin adl, BindingResult br, HttpServletRequest rq) {
        ModelAndView mv = new ModelAndView("adminlogin");
        if (br.hasErrors()) {
            return mv;
        } else {
            AdminSignupJDBCTemplate adjdbctemplate = new AdminSignupJDBCTemplate();
            int id = adjdbctemplate.checkLogin(adl.getEmail(), AES.encrypt(adl.getPass(), "password"));
            if (id == 0) {
                mv.addObject("err", "true");
                mv.addObject("errData", "Invalid username and password!");
                return mv;
            } else {
                boolean v=adjdbctemplate.checkVerified(adl.getEmail());
                boolean f=adjdbctemplate.checkFlag(adl.getEmail());
                if(v==true && f==true)
                {
                HttpSession session = rq.getSession();
                session.setAttribute("adminID", id);
                return new ModelAndView("redirect:/admin/adquestionindex");
                }
                else if(!v)
                {
                 mv.addObject("err", "true");
                mv.addObject("errData", "Please Active Your Account follow Request to Admin button !");
                return mv;
                }
                else if(!f)
                {
                 mv.addObject("err", "true");
                mv.addObject("errData", "Please Contact your super Admin !");
                return mv;
                }
                
            }
            return mv;
        }
    }

    @RequestMapping(value = "/adlogout", method = RequestMethod.GET)
    public String logOut(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        session.setAttribute("adminID", null);
        session.invalidate();
        return "redirect:/admin/";
    }

    @RequestMapping(value = "requesttoadmin", method = RequestMethod.POST)
    public ModelAndView adminLoginRequest(@Valid @ModelAttribute("reqadmin") AdminRequest adr, BindingResult br, HttpServletRequest req) {
        HttpSession session = req.getSession();
        ModelAndView mv = new ModelAndView("adminlogin");
         String email = adr.getEmail();
                String otp = RandomString.generate(5);
                
        if (br.hasErrors()) {
            mv.addObject("err", "true");
            mv.addObject("errData", "Invalid Data Entry");
            return mv;
        } else {
            AdminSignupJDBCTemplate adjdbctemplate = new AdminSignupJDBCTemplate();
            boolean b = adjdbctemplate.insert(adr.getName(), adr.getEmail(), adr.getCid(), AES.encrypt(adr.getPass2(), "password"),otp);
            if (b == false) {
                boolean f = adjdbctemplate.checkVerified(adr.getEmail());
                if (f) {
                    mv.addObject("err", "true");
                    mv.addObject("errData", "Already Registered!");
                } else {
                    mv.addObject("err", "true");
                    mv.addObject("errData", "Please Active your account");
                }
                return mv;
            } else {
                    ModelAndView mv2 = new ModelAndView("adminlogin_otp");
                    session.setAttribute("adminEmail", adr.getEmail());
                    SendMailTLS.send(email, req.getContextPath(), "OTP :  " + otp);
                    return mv2;
            }

        }
    }

    @RequestMapping(value = "check-otp", method = RequestMethod.POST)
    public ModelAndView checkOTP(HttpServletRequest rq, @ModelAttribute("email") String email, @ModelAttribute("otp") String otp) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") == null) {
            AdminSignupJDBCTemplate asjt = new AdminSignupJDBCTemplate();
            
            Integer id = asjt.checkOTP(email, otp);
            if (id != 0) {                
                session.setAttribute("adminEmail", null);
                ModelAndView mv=new ModelAndView("adminlogin");
                mv.addObject("info", true);
                mv.addObject("infoData", "Please wait until super admin permission your account");
                return mv;
            } else {
                ModelAndView mv = new ModelAndView("adminlogin_otp");
                mv.addObject("err", true);
                mv.addObject("errData", "Invalid OTP");
                session.setAttribute("adminEmail", email);
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "resend-otp", method = RequestMethod.GET)
    public ModelAndView reSendOTP(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") == null) {
            AdminSignupJDBCTemplate asjt = new AdminSignupJDBCTemplate();
            String email = (String) session.getAttribute("adminEmail");
            String otp = RandomString.generate(5);
            boolean b = asjt.updateOTP(email, otp);
            ModelAndView mv = new ModelAndView("adminlogin_otp");
            if (b) {
                SendMailTLS.send(email, rq.getContextPath(), "OTP :  " + otp);
                return mv;
            } else {
                mv.addObject("err", true);
                mv.addObject("errData", "Try again after some time ");
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "adquestionindex", method = RequestMethod.GET)
    public String adminQuestionIndexPage(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            return "adminquestionindex";
        } else {
            return "redirect:/admin/";
        }
    }

    @RequestMapping(value = "/submitquestionsetname", method = RequestMethod.POST)
    public ModelAndView adminSubmitQuestionSet(@Valid @ModelAttribute("qset") QuestionSetName qsn, BindingResult br, HttpServletRequest rq) {
        ModelAndView mv = new ModelAndView("adminquestionindex");
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            if (br.hasErrors()) {
                mv.addObject("err", "true");
                mv.addObject("errData", "Invalid Data Entry");
                return mv;
            } else {
                QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
                Integer qsid = qsjt.insert((Integer) session.getAttribute("adminID"), qsn.getExam_set(), qsn.getExam_stime(), qsn.getExam_etime(), qsn.getExam_date());
                if (qsid == null) {
                    mv.addObject("err", "true");
                    mv.addObject("errData", "Invalid Data Entry");
                    return mv;
                } else {
                    session.setAttribute("qsid", qsid);
                    return new ModelAndView("redirect:/admin/adquestion");
                }
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }

    }

    @RequestMapping(value = "/adquestion", method = RequestMethod.GET)
    public ModelAndView adminQuestion(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null && session.getAttribute("qsid") != null) {
            QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
            QuestionSetName qsn = qsjt.getData((Integer) session.getAttribute("qsid"));
            ModelAndView mv = new ModelAndView("adminquestion");
            mv.addObject("setName", qsn.getExam_set());
            mv.addObject("sTime", qsn.getExam_stime());
            mv.addObject("eTime", qsn.getExam_etime());
            mv.addObject("date", qsn.getExam_date());
            return mv;
        } else {
            return new ModelAndView("redirect:/admin/");
        }

    }

    @RequestMapping(value = "/submit-admin-question", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = "application/json")
    @ResponseBody
    public String submitAdminQuestion(@RequestBody String qs, HttpServletRequest rq) throws JSONException {
        int flag = 0;
        boolean c = false;
        String r = "";
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null && session.getAttribute("qsid") != null) {

            JSONObject jsonObject = new JSONObject(qs);
            String qus = jsonObject.getString("qus");
            String qA = jsonObject.getString("qA");
            String qB = jsonObject.getString("qB");
            String qC = jsonObject.getString("qC");
            String qD = jsonObject.getString("qD");
            String optradio = jsonObject.getString("optradio");
            char op = optradio.charAt(0);
            if ((!qus.isEmpty() || qus != null) && (!qA.isEmpty() || qA != null) || (qB.isEmpty() || qB != null) || (!qC.isEmpty() || qC != null) || (!qD.isEmpty() || qD != null) || (!optradio.isEmpty() || optradio != null)) {

                if (qus.length() < 800 && qA.length() < 800 && qB.length() < 800 && qC.length() < 800 && qD.length() < 800) {
                    if ('A' == op || 'B' == op || 'C' == op || 'D' == op) {
                        flag = 10;
                    } else {
                        flag = -1;
                    }
                } else {
                    flag = 1;
                }
            } else {
                flag = 0;
            }

            if (flag == 10) {
                Question q = new Question();
                q.setQus(qus);
                q.setqA(qA);
                q.setqB(qB);
                q.setqC(qC);
                q.setqD(qD);
                q.setOptradio(optradio);
                Integer sid = (Integer) session.getAttribute("qsid");
                QuestionJDBCTemplate qjdbct = new QuestionJDBCTemplate();
                c = qjdbct.insert(sid, q.getQus(), q.getqA(), q.getqB(), q.getqC(), q.getqD(), q.getOptradio());
                r = "" + qjdbct.countQuestion(sid);
            } else {
                flag = -10;
            }

        } else {
            return "Invalid Admin";
        }
        if (c == true && flag == 10) {
            flag = 10;
        } else {
            flag = -10;
        }
        return r;
    }

    @RequestMapping(value = "old-question-sets", method = RequestMethod.GET)
    public ModelAndView adminOldQuestion(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            QuestionSetNameJdbcTemplate qsnjt = new QuestionSetNameJdbcTemplate();
            List<QuestionSetName> qsn = qsnjt.getDataById((Integer) session.getAttribute("adminID"));
            if (qsn != null) {
                ModelAndView mv = new ModelAndView("old_question_set");
                mv.addObject("qsn", qsn);
                return mv;
            } else {
                return new ModelAndView("redirect:/admin/");
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "old-question-details/{qsid}", method = RequestMethod.GET)
    public ModelAndView adminOldQuestionDetals(HttpServletRequest rq, @PathVariable("qsid") Integer qsid) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            ModelAndView mv = new ModelAndView("admin_question_details");
            QuestionSetNameJdbcTemplate qsnjt = new QuestionSetNameJdbcTemplate();
            QuestionSetName qsn = qsnjt.getData(qsid, (Integer) session.getAttribute("adminID"));
            QuestionJDBCTemplate qjt = new QuestionJDBCTemplate();
            if (qsn != null) {
                List<Question> questions = qjt.getQuestion(qsid);
                mv.addObject("questions", questions);
                mv.addObject("qsn", qsn);
                session.setAttribute("qsid", qsid);
                return mv;
            } else {
                return new ModelAndView("redirect:/admin/");
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "delete-question/{qid}", method = RequestMethod.GET)
    public ModelAndView adminQuestionDelete(HttpServletRequest rq, @PathVariable("qid") Integer qid) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            QuestionJDBCTemplate qjt = new QuestionJDBCTemplate();
            boolean r = qjt.questionDelete(qid);
            if (r == true) {
                Integer qsid = (Integer) session.getAttribute("qsid");
                return new ModelAndView("redirect:/admin/old-question-details/" + qsid);
            } else {
                return new ModelAndView("redirect:/admin/");
            }

        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "update-question-set", method = RequestMethod.POST)
    public ModelAndView adminUpdateQuestionSet(@ModelAttribute("questionset") QuestionSetName qsn, HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {

            QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
            boolean b = qsjt.updateQuestionSet((Integer) session.getAttribute("qsid"), qsn.getExam_set(), qsn.getExam_stime(), qsn.getExam_etime(), qsn.getExam_date());
            if (b == true) {
                ModelAndView mv = new ModelAndView("adminquestion");
                mv.addObject("setName", qsn.getExam_set());
                mv.addObject("sTime", qsn.getExam_stime());
                mv.addObject("eTime", qsn.getExam_etime());
                mv.addObject("date", qsn.getExam_date());
                return mv;
            } else {
                return new ModelAndView("redirect:/admin/");
            }

        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "admin-marks", method = RequestMethod.GET)
    public ModelAndView adminMarks(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            ModelAndView mv = new ModelAndView("question_set_for_marks");
            QuestionSetNameJdbcTemplate qsnjt = new QuestionSetNameJdbcTemplate();
            List<QuestionSetName> qsn = (List<QuestionSetName>) qsnjt.getDataById((Integer) session.getAttribute("adminID"));
            if (qsn != null) {
                mv.addObject("qsn", qsn);
                return mv;
            } else {
                return new ModelAndView("redirect:/admin/");
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "students-marks-details/{qsid}", method = RequestMethod.GET)
    public ModelAndView studentsMarksDetails(HttpServletRequest rq, @PathVariable("qsid") Integer qsid) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            ModelAndView mv = new ModelAndView("admin_marks_details");
            AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
            if (asjt.isPresentSid(qsid)) {
                List<Integer> luid = asjt.getUid(qsid);
                if (luid != null) {
                    mv.addObject("luid", luid);
                    mv.addObject("sid", qsid);
                    return mv;
                } else {
                    return new ModelAndView("redirect:/admin/");
                }
            } else {
                return new ModelAndView("redirect:/admin/");
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "students-answer-script-details/{uid}/{sid}", method = RequestMethod.GET)
    public ModelAndView studentsAnswerScriptDetails(HttpServletRequest rq, @PathVariable("uid") Integer uid, @PathVariable("sid") Integer sid) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            ModelAndView mv = new ModelAndView("marks_and_details_admin");
            QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
            QuestionSetName qsn = qsjt.getData(sid);
            if (qsn != null) {
                AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
                int marks = asjt.getMarks(uid, sid);
                QuestionJDBCTemplate qjt = new QuestionJDBCTemplate();
                List<Question> questions = qjt.getQuestion(sid);
                AnswerSubmitJDBCTemplate ans = new AnswerSubmitJDBCTemplate();
                mv.addObject("qsn", qsn);
                mv.addObject("marks", marks);
                mv.addObject("questions", questions);
                mv.addObject("ans", ans);
                mv.addObject("uid", uid);
                return mv;
            } else {
                return new ModelAndView("redirect:/admin/");
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "admin-profile", method = RequestMethod.GET)
    public ModelAndView adminProfile(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("adminID") != null) {
            AdminSignupJDBCTemplate asjt = new AdminSignupJDBCTemplate();
            AdminRequest2 admin = asjt.getData((Integer) session.getAttribute("adminID"));
            if (admin != null) {
                ModelAndView mv = new ModelAndView("admin_profile");
                mv.addObject("admin", admin);
                return mv;
            } else {
                return new ModelAndView("redirect:/admin/");
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }
    }

    @RequestMapping(value = "admin-update-profile", method = RequestMethod.POST)
    public ModelAndView adminUpdateProfile(@Valid @ModelAttribute("adupdate") UserUpdateProfile adp, BindingResult br, HttpServletRequest rq) {
        HttpSession session = rq.getSession();

        if (session.getAttribute("adminID") != null) {

            ModelAndView mv = new ModelAndView("admin_profile");
            AdminSignupJDBCTemplate asjt = new AdminSignupJDBCTemplate();
            AdminRequest2 admin = asjt.getData((Integer) session.getAttribute("adminID"));
            if (admin != null) {
                mv.addObject("admin", admin);
            }

            if (br.hasErrors()) {
                mv.addObject("err", true);
                mv.addObject("errData", "Invalid data");
                if (adp.getPass1() == null) {
                    mv.addObject("passData", "Password Not Matched");
                } else {
                    mv.addObject("passData", "");
                }
                return mv;
            } else {
                boolean b = asjt.updateAdminProfile((Integer) session.getAttribute("adminID"), adp.getEmail(), AES.encrypt(adp.getPass1(), "password"));
                if (!b) {
                    mv.addObject("err", true);
                    mv.addObject("errData", "Invalid data");
                    return mv;
                } else {
                    mv.addObject("info", true);
                    mv.addObject("infoData", "Your password is changed");
                }
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/admin/");
        }

    }

    @RequestMapping(value = "re-generate-referral-code/{qsid}", method = RequestMethod.GET)
    public ModelAndView reGenerateReferralCode(HttpServletRequest rq, @PathVariable("qsid") Integer qsid) {
        HttpSession session = rq.getSession();
        ReferralKeyJdbcTemplate rkjt = new ReferralKeyJdbcTemplate();
        if (session.getAttribute("adminID") != null) {
            rkjt.generateKey(qsid, RandomString.generate(5));
            return new ModelAndView("redirect:/admin/old-question-sets");
        } else {
            return new ModelAndView("redirect:/admin/");
        }

    }

    @RequestMapping(value = "get-forget-password", method = RequestMethod.POST)
    public ModelAndView getForgetPassword(HttpServletRequest rq, @ModelAttribute("email") String email) {
        ModelAndView mv=new ModelAndView("adminlogin");
        AdminSignupJDBCTemplate adsjt = new AdminSignupJDBCTemplate();
        AdminRequest2 ad = adsjt.getPassword(email);
        if (ad != null) {
            String pass = AES.decrypt(ad.getPass2(), "password");
            SendMailTLS.send(email, rq.getContextPath(), "Paasword:  " + pass);
             mv.addObject("info", true);
                mv.addObject("info", "Please check your email ");
                return mv;
        }
        else
        {
             mv.addObject("err", true);
                mv.addObject("errData", "Invalid Email Id ");
                return mv;
        }
    }

    @RequestMapping(value = "active-Account-Get-otp", method = RequestMethod.POST)
    public ModelAndView activeAccountGetOTP(HttpServletRequest rq, @ModelAttribute("email") String email) {
        HttpSession session = rq.getSession();
        ModelAndView mv = new ModelAndView("adminlogin_otp");
        if (session.getAttribute("adminID") == null) {
            AdminSignupJDBCTemplate asjt = new AdminSignupJDBCTemplate();
            String otp = RandomString.generate(5);
            boolean b = asjt.updateOTP(email, otp);
            if (b) {
                SendMailTLS.send(email, rq.getContextPath(), "OTP :  " + otp);
                return mv;
            } else {
                mv.addObject("err", true);
                mv.addObject("errData", "Try again after some time ");
                return mv;
            }
        }
        return mv;
    }

}
