package com.examportal.controller;

import com.examportal.adminservice.Question;
import com.examportal.adminservice.QuestionSetName;
import com.examportal.database.QuestionJDBCTemplate;
import com.examportal.database.QuestionSetNameJdbcTemplate;
import com.examportal.database.ReferralKeyJdbcTemplate;
import com.examportal.database.user.AnswerSubmitJDBCTemplate;
import com.examportal.database.user.UserSignupJdbcTemplate;
import com.examportal.email.SendMailTLS;
import com.examportal.security.AES;
import com.examportal.service.RandomString;
import com.examportal.timemanagement.DateTimeManagement;
import com.examportal.timemanagement.TimeManageMent;
import com.examportal.timemanagement.TimeThread;
import com.examportal.userservice.UserLogin;
import com.examportal.userservice.UserSignup;
import com.examportal.userservice.UserUpdateProfile;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author amiya
 */
@Controller
@RequestMapping("/")
public class UserController {

    @RequestMapping(method = RequestMethod.GET)
    public String userRoot(HttpServletRequest rq, HttpServletResponse res) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null) {
            Cookie ck = new Cookie("userEmail", "");
            ck.setMaxAge(0);
            res.addCookie(ck);
            return "redirect:user-page";
        } else {
            return "usrindex";
        }
    }

    @RequestMapping(value = "user-page", method = RequestMethod.GET)
    public ModelAndView userPage(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null) {
            ModelAndView mv = new ModelAndView("userpage");
            AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
            List<Integer> sids = asjt.getSid((Integer) session.getAttribute("userid"));
            mv.addObject("sids", sids);
            mv.addObject("uid", (Integer) session.getAttribute("userid"));
            return mv;
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "user-logout", method = RequestMethod.GET)
    public String userLogout(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        session.setAttribute("userid", null);
        session.invalidate();
        return "redirect:/";
    }

    @RequestMapping(value = "user-logout-referral", method = RequestMethod.GET)
    public String userLogoutReferral(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        session.setAttribute("qsid", null);
        return "redirect:/";
    }

    @RequestMapping(value = "user-login", method = RequestMethod.POST)
    public ModelAndView userLogin(@Valid @ModelAttribute("userlogin") UserLogin ul, BindingResult br, HttpServletRequest rq,HttpServletResponse res) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") == null) {
            ModelAndView mv = new ModelAndView("usrindex");
            if (br.hasErrors()) {
                return mv;
            } else {
                UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
                int id = usjt.checkLogin(ul.getEmail(), AES.encrypt(ul.getPass(), "password"));
                boolean b = usjt.checkverified(ul.getEmail(), AES.encrypt(ul.getPass(), "password"));
                if (b) {
                    mv.addObject("errf", "true");
                    mv.addObject("errData", "Please active your account");
                    return mv;

                } else if (id == 0) {
                    mv.addObject("errf", "true");
                    mv.addObject("errData", "Invalid username and password!");
                    return mv;
                } else {
                    session.setAttribute("userid", id);
                    return new ModelAndView("redirect:/user-page");
                }

            }
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "user-signup", method = RequestMethod.POST)
    public ModelAndView userSignup(@Valid @ModelAttribute("usersignup") UserSignup us, BindingResult br, HttpServletResponse res, HttpServletRequest req) {
        HttpSession session = req.getSession();
        ModelAndView mv = new ModelAndView("usrindex");
        if (br.hasErrors()) {
            mv.addObject("err", "true");
            mv.addObject("errData", "Invalid Data Entry");
            return mv;
        } else {
            UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
            boolean b = usjt.insert(us.getName(), us.getEmail(), us.getRoll(), us.getGender(), AES.encrypt(us.getPass(), "password"));
            if (b == false) {
                mv.addObject("err", "true");
                mv.addObject("errData", "Already Registered");
                return mv;
            } else {
                String email = us.getEmail();
                String otp = RandomString.generate(5);
                boolean r = usjt.updateOTP(email, otp);
                if (!r) {
                    mv.addObject("err", "true");
                    mv.addObject("errData", "Something wrong");
                    return mv;
                } else {
                    ModelAndView mv2 = new ModelAndView("user_otp");
                    session.setAttribute("userEmail", us.getEmail());
                    SendMailTLS.send(email, req.getContextPath(), "OTP :  " + otp);
                    return mv2;

                }

            }

        }
    }

    @RequestMapping(value = "check-otp", method = RequestMethod.POST)
    public ModelAndView checkOTP(HttpServletRequest rq, @ModelAttribute("email") String email, @ModelAttribute("otp") String otp) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") == null) {
            UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
            Integer id = usjt.checkOTP(email, otp);
            if (id != 0) {
                session.setAttribute("userid", id);
                session.setAttribute("userEmail", null);
                return new ModelAndView("redirect:/");
            } else {
                ModelAndView mv = new ModelAndView("user_otp");
                mv.addObject("err", true);
                mv.addObject("errData", "Invalid OTP");
                session.setAttribute("userEmail", email);
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "resend-otp", method = RequestMethod.GET)
    public ModelAndView reSendOTP(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") == null) {
            UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
            String email = (String) session.getAttribute("userEmail");
            String otp = RandomString.generate(5);
            boolean b = usjt.updateOTP(email, otp);
            ModelAndView mv = new ModelAndView("user_otp");
            if (b) {
                SendMailTLS.send(email, rq.getContextPath(), "OTP :  " + otp);
                return mv;
            } else {
                mv.addObject("err", true);
                mv.addObject("errData", "Try again after some time ");
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "get-forget-password", method = RequestMethod.POST)
    public ModelAndView getForgetPassword(HttpServletRequest rq, @ModelAttribute("email") String email) {
        UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
        UserSignup us = usjt.getPassword(email);
        if (us != null) {
            String pass = AES.decrypt(us.getPass(), "password");
            SendMailTLS.send(email, rq.getContextPath(), "Paasword:  " + pass);
        }
        return new ModelAndView("redirect:/");
    }

    @RequestMapping(value = "active-Account-Get-otp", method = RequestMethod.POST)
    public ModelAndView activeAccountGetOTP(HttpServletRequest rq, @ModelAttribute("email") String email) {
        HttpSession session = rq.getSession();
        ModelAndView mv = new ModelAndView("user_otp");
        if (session.getAttribute("userid") == null) {
            UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
            String otp = RandomString.generate(5);
            boolean b = usjt.updateOTP(email, otp);
            if (b) {
                SendMailTLS.send(email, rq.getContextPath(), "OTP :  " + otp);
                return mv;
            } else {
                mv.addObject("err", true);
                mv.addObject("errData", "Try again after some time ");
                return mv;
            }

        }
        return mv;
    }

    @RequestMapping(value = "today-examination-sets", method = RequestMethod.GET)
    public ModelAndView userExamination(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null) {
            QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            List<QuestionSetName> qs = qsjt.getDataToday(formatter.format(new Date()));
            ModelAndView mv = new ModelAndView("todayexaminationsets");
            mv.addObject("qs", qs);
            return mv;
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "check-referral-code", method = RequestMethod.POST)
    public ModelAndView checkReferralCode(@RequestParam("qsid") Integer qsid, @RequestParam("rc") String rc, HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null) {
            QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
            boolean b = qsjt.checkReferralCode(qsid, rc);
            if (b == true) {
                session.setAttribute("qsid", qsid);
                return new ModelAndView("redirect:/start-exam");
            } else {
                ModelAndView mv = new ModelAndView("todayexaminationsets");
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                List<QuestionSetName> qs = qsjt.getDataToday(formatter.format(new Date()));
                mv.addObject("qs", qs);
                mv.addObject("err", "true");
                mv.addObject("errData", "Invalid Referral Code");
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "start-exam", method = RequestMethod.GET)
    public ModelAndView startExam(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null && session.getAttribute("qsid") != null) {

            QuestionJDBCTemplate question = new QuestionJDBCTemplate();
            List<Question> qus = question.getQuestion((Integer) session.getAttribute("qsid"));
            QuestionSetNameJdbcTemplate qsetName = new QuestionSetNameJdbcTemplate();
            QuestionSetName qsetname = qsetName.getData((Integer) session.getAttribute("qsid"));
            TimeManageMent tm = new TimeManageMent();
            int minutes = tm.getMinutesWithString(qsetname.getExam_stime(), qsetname.getExam_etime());
            DateTimeManagement dtm = new DateTimeManagement();
            Date d = new Date();
            String nt = d.getHours() + ":" + d.getMinutes();
            boolean b = dtm.checkTime(qsetname.getExam_stime(), qsetname.getExam_etime(), nt);
            ModelAndView mv = new ModelAndView("examination");
            mv.addObject("err", "false");
            if (qus != null && qsetname != null && minutes != 0 && b == true) {

                final Integer rmin = tm.getMinutesWithString(nt, qsetname.getExam_etime());
                TimeThread td = new TimeThread(rq);
                td.setI(rmin * 60 - d.getSeconds());
                td.start();

                mv.addObject("qsetname", qsetname);
                mv.addObject("qus", qus);
                mv.addObject("minutes", minutes);
                mv.addObject("rsec", td.getI());
                mv.addObject("td", td);
                mv.addObject("userid", session.getAttribute("userid"));
                return mv;
            } else {
                mv.addObject("err", "true");
                mv.addObject("errData", "Invalid Timing");
                return mv;
            }
        }

        return new ModelAndView("redirect:/");
    }

    @RequestMapping(value = "answer-submit", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = "application/json")
    @ResponseBody
    public String answerSubmit(@RequestBody String ans, HttpServletRequest rq) throws JSONException {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null && session.getAttribute("qsid") != null) {

            JSONObject jsonObject = new JSONObject(ans);
            Integer sid = Integer.parseInt(jsonObject.getString("sid"));
            Integer qid = Integer.parseInt(jsonObject.getString("qid"));
            String answer = jsonObject.getString("answer");

            if (("A".equals(answer) || "B".equals(answer) || "C".equals(answer) || "D".equals(answer))) {
                AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
                boolean ab = asjt.checkInsert(qid);
                if (ab == true) {
                    boolean b = asjt.update(qid, answer);
                    if (b == true) {
                        return "true";
                    } else {
                        return "false";
                    }
                } else {
                    boolean b = asjt.insert(sid, (int) session.getAttribute("userid"), qid, answer);
                    if (b == true) {
                        return "true";
                    } else {
                        return "false";
                    }
                }

            } else {
                return "invalid_option";
            }
        }
        return "invalid_user";
    }

    @RequestMapping(value = "user-marks/{sid}", method = RequestMethod.GET)
    public ModelAndView userMarks(HttpServletRequest rq, @PathVariable("sid") int sid) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null) {
            QuestionSetNameJdbcTemplate qsjt = new QuestionSetNameJdbcTemplate();
            QuestionSetName qsn = qsjt.getData(sid);
            if (qsn != null) {
                ModelAndView mv = new ModelAndView("marks_and_details");
                AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
                int marks = asjt.getMarks((Integer) session.getAttribute("userid"), sid);
                QuestionJDBCTemplate qjt = new QuestionJDBCTemplate();
                List<Question> questions = qjt.getQuestion(sid);
                AnswerSubmitJDBCTemplate ans = new AnswerSubmitJDBCTemplate();
                mv.addObject("qsid", sid);
                mv.addObject("qsn", qsn);
                mv.addObject("marks", marks);
                mv.addObject("questions", questions);
                mv.addObject("ans", ans);
                mv.addObject("uid", (Integer) session.getAttribute("userid"));
                return mv;
            } else {
                return new ModelAndView("redirect:/");
            }
        } else {
            return new ModelAndView("redirect:/");
        }
    }

    @RequestMapping(value = "user-update-profile", method = RequestMethod.POST)
    public ModelAndView userUpdateProfile(HttpServletRequest rq, @Valid @ModelAttribute("userupdate") UserUpdateProfile up, BindingResult br) {
        HttpSession session = rq.getSession();
        if (session.getAttribute("userid") != null) {
            ModelAndView mv = new ModelAndView("userpage");
            AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
            List<Integer> sids = asjt.getSid((Integer) session.getAttribute("userid"));
            mv.addObject("sids", sids);
            mv.addObject("uid", (Integer) session.getAttribute("userid"));
            if (br.hasErrors()) {
                mv.addObject("err", true);
                mv.addObject("errData", "Invalid data");
                
                if (up.getPass1() == null) {
                    mv.addObject("passData", "Password Not Matched");
                } else {
                    mv.addObject("passData", "");
                }
                return mv;
            }
            UserSignupJdbcTemplate usjt = new UserSignupJdbcTemplate();
            boolean b = usjt.updateProfile((Integer) session.getAttribute("userid"), up.getEmail(), AES.encrypt(up.getPass1(), "password"));
            if (!b) {
                mv.addObject("err", true);
                mv.addObject("errData", "Invalid data");
                 return mv;
            }
            else
            {
                mv.addObject("info", true);
                mv.addObject("infoData", "Your password Changed");
                return mv;
            }
            
        } else {
            return new ModelAndView("redirect:/");
        }
    }

}
