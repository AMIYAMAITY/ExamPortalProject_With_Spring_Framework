
package com.examportal.controller;


import com.examportal.adminservice.AdminRequest2;
import com.examportal.adminservice.QuestionSetName;
import com.examportal.database.AdminSignupJDBCTemplate;
import com.examportal.database.QuestionSetNameJdbcTemplate;
import com.examportal.database.ReferralKeyJdbcTemplate;
import com.examportal.database.user.AnswerSubmitJDBCTemplate;
import com.examportal.database.user.UserSignupJdbcTemplate;
import com.examportal.security.AES;
import com.examportal.service.RandomString;
import com.examportal.superadmin.SuperAdminLogin;
import com.examportal.superadmin.SuperAdminUpdateProfile;
import com.examportal.superadmin.database.SuperAdminJdbcTemplate;
import com.examportal.userservice.UserSignup;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author amiya
 */

@Controller
@RequestMapping("/super_admin")
public class SuperAdminController 
{
      @RequestMapping(method = RequestMethod.GET)
    public String indexLoginSuperAdmin(HttpServletRequest rq) {
 HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            return "redirect:/super_admin/super-admin-index";
        } else {
            return "super_adminlogin";
        }   
    }
    
     @RequestMapping(value = "suadmin-logout", method = RequestMethod.GET)
    public String superAdminLogout(HttpServletRequest rq) {
        HttpSession session = rq.getSession();
        session.setAttribute("super_adminid", null);
        session.invalidate();
        return "redirect:/super_admin";
    }
    
    @RequestMapping(value = "super-admin-login",method = RequestMethod.POST)
    public ModelAndView superAdminLogin(@Valid @ModelAttribute("su_adlogin") SuperAdminLogin sad,BindingResult br,HttpServletRequest rq) {
          HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") == null) {
        ModelAndView mv = new ModelAndView("super_adminlogin");
        if (br.hasErrors()) {
            return mv;
        } else {
            SuperAdminJdbcTemplate adjt=new SuperAdminJdbcTemplate();
            int id = adjt.checkLogin(sad.getEmail(),AES.encrypt(sad.getPass2(), "password"));
            if (id == 0) {
                mv.addObject("err", "true");
                mv.addObject("errData", "Invalid username and password!");
                return mv;
            } else {
                session.setAttribute("super_adminid", id);
                return new ModelAndView("redirect:/super_admin/super-admin-index");
           }
        }
        }
        else
            return new ModelAndView("redirect:/super_admin");
    }
    
       @RequestMapping(value="super-admin-index",method = RequestMethod.GET)
    public ModelAndView indexSuperAdmin(HttpServletRequest rq) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            AdminSignupJDBCTemplate asjt=new AdminSignupJDBCTemplate();
            List<AdminRequest2> adminsf0=asjt.getAdminsData(0);
            List<AdminRequest2> adminsf1=asjt.getAdminsData(1);
            SuperAdminJdbcTemplate sajt=new SuperAdminJdbcTemplate();
                SuperAdminUpdateProfile saup=sajt.getData((Integer)session.getAttribute("super_adminid"));
            ModelAndView mv=new ModelAndView("super_admin_index");
            if(adminsf0==null || adminsf1==null || saup==null)
            {
                return new ModelAndView("redirect:/super_admin");
            }
            else
            {
                
                mv.addObject("saup", saup);
                 mv.addObject("adminsf0", adminsf0);
                 mv.addObject("adminsf1", adminsf1);
                return mv;
            }
        } else {
            return new ModelAndView("redirect:/super_admin");
        }   
    }
    
      @RequestMapping(value = "update-make-admin-flag/{id}", method = RequestMethod.GET)
    public String makeAdmin(HttpServletRequest rq,@PathVariable("id") Integer id) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            AdminSignupJDBCTemplate asjt=new AdminSignupJDBCTemplate();
            boolean r=asjt.updateFlag(id, 1);
            if(r==false)
                return "redirect:/super_admin/suadmin-logout";
            else
            return "redirect:/super_admin/super-admin-index";
        }
      else
          return "redirect:/super_admin";
        
    }
    
       @RequestMapping(value = "update-cancel-admin-flag/{id}", method = RequestMethod.GET)
    public String cancelAdmin(HttpServletRequest rq,@PathVariable("id") Integer id) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            AdminSignupJDBCTemplate asjt=new AdminSignupJDBCTemplate();
            boolean r=asjt.updateFlag(id, 0);

            if(r==false)
                return "redirect:/super_admin/suadmin-logout";
            else
            return "redirect:/super_admin/super-admin-index";
        }
      else
          return "redirect:/super_admin";
    }
    
    
       @RequestMapping(value = "super-admin-update-profile", method = RequestMethod.POST)
    public String updateProfile(HttpServletRequest rq,@Valid @ModelAttribute("suupdate") SuperAdminLogin sal,BindingResult br) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
           if(!br.hasErrors())
           {
               SuperAdminJdbcTemplate sajt=new SuperAdminJdbcTemplate();
             boolean b=  sajt.updateProfile(sal.getEmail(), AES.encrypt(sal.getPass2(), "password"), (Integer)session.getAttribute("super_adminid"));
             if(b==true)
             {
               return "redirect:/super_admin/super-admin-index";
             }
             else
               return "redirect:/super_admin/suadmin-logout";
           }
           else
           {
               return "redirect:/super_admin/suadmin-logout";
           }
        }
      else
          return "redirect:/super_admin";
    }
    
          @RequestMapping(value = "super-admin-questionset", method = RequestMethod.GET)
    public ModelAndView superAdminQuestionSet(HttpServletRequest rq) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            QuestionSetNameJdbcTemplate qsnjt = new QuestionSetNameJdbcTemplate();
            List<QuestionSetName> qsn = qsnjt.getAllData();
            if (qsn != null) {
                ModelAndView mv = new ModelAndView("super_admin_questionset");
                mv.addObject("qsn", qsn);
                return mv;
            } else {
                return new ModelAndView( "redirect:/super_admin");
            }
        }
      else
          return new ModelAndView( "redirect:/super_admin");
    }
    
    
      @RequestMapping(value = "super-admin-students-list", method = RequestMethod.GET)
    public ModelAndView superAdminStudentsList(HttpServletRequest rq) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            UserSignupJdbcTemplate usjt=new UserSignupJdbcTemplate();
            List<UserSignup> students=usjt.getDataAll();
            if (students != null) {
                ModelAndView mv = new ModelAndView("super_admin_students_list");
                mv.addObject("students", students);
                return mv;
            } else {
                return new ModelAndView( "redirect:/super_admin");
            }
        }
      else
          return new ModelAndView( "redirect:/super_admin");
    }
    
      @RequestMapping(value = "super-admin-marks", method = RequestMethod.GET)
    public ModelAndView superAdminMarksPage(HttpServletRequest rq) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            QuestionSetNameJdbcTemplate qsnjt = new QuestionSetNameJdbcTemplate();
            List<QuestionSetName> qsn = qsnjt.getAllData();
            if (qsn != null) {
                ModelAndView mv = new ModelAndView("super_admin_marks");
                mv.addObject("qsn", qsn);
                return mv;
            } else {
                return new ModelAndView( "redirect:/super_admin");
            }
        }
      else
          return new ModelAndView( "redirect:/super_admin");
    }
    
     @RequestMapping(value = "super-admin-marks/{qsid}", method = RequestMethod.GET)
    public ModelAndView superAdminMarks(HttpServletRequest rq,@PathVariable("qsid") Integer id) {
         HttpSession session = rq.getSession();
        if (session.getAttribute("super_adminid") != null) {
            AnswerSubmitJDBCTemplate asjt = new AnswerSubmitJDBCTemplate();
            List<Integer> uids=asjt.getUid(id);
            if (uids != null) {
                
                ModelAndView mv = new ModelAndView("super_admin_students_marks_details");
                mv.addObject("uids", uids);
                mv.addObject("qsid", id);
                return mv;
            } else {
                return new ModelAndView( "redirect:/super_admin");
            }
        }
      else
          return new ModelAndView( "redirect:/super_admin");
    }
    
    
    
    
     @RequestMapping(value = "re-generate-referral-code/{qsid}", method = RequestMethod.GET)
    public ModelAndView reGenerateReferralCode(HttpServletRequest rq,@PathVariable("qsid") Integer qsid) {
       HttpSession session = rq.getSession();
       ReferralKeyJdbcTemplate rkjt=new ReferralKeyJdbcTemplate();
        if (session.getAttribute("super_adminid") != null) {
            rkjt.generateKey(qsid , RandomString.generate(5));
            return new ModelAndView("redirect:/super_admin/super-admin-questionset");
        }
        else
        {
            return new ModelAndView( "redirect:/super_admin");
        }
        
    }
    
}
