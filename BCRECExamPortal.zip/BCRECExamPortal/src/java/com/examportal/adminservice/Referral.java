
package com.examportal.adminservice;

/**
 *
 * @author amiya
 */
public class Referral 
{
    Integer qsid;
    String referral_key;

    public Integer getQsid() {
        return qsid;
    }

    public void setQsid(Integer qsid) {
        this.qsid = qsid;
    }

    public String getReferral_key() {
        return referral_key;
    }

    public void setReferral_key(String referral_key) {
        this.referral_key = referral_key;
    }
}
