package com.examportal.adminservice;

import com.examportal.customvalidation.CusOption;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

/**
 *
 * @author amiya
 */
public class Question
{

    @NotEmpty(message="Data Required")
    @Size(min = 1, max = 50000, message = "Data must be in between 1 to 50000")
    private String qus;
    
    @NotEmpty(message="Data Required")
    @Size(min = 1, max = 800, message = "Data must be in between 1 to 800")
    private String qA;
    
   @NotEmpty(message="Data Required")
   @Size(min = 1, max = 800, message = "Data must be in between 1 to 800")
    private String qB;
    
   @NotEmpty(message="Data Required")
    @Size(min = 1, max = 800, message = "Data must be in between 1 to 800")
    private String qC;
    
   @NotEmpty(message="Data Required")
    @Size(min = 1, max = 800, message = "Data must be in between 1 to 800")
    private String qD;
    
   @Size(min = 1, max = 3, message = "Data must be in between 1 to 3")
    @NotEmpty(message="Data Required")
    @CusOption(message="Invalid Data")
    private String optradio;
    
    private Integer sid;
    private Integer qid;



    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Integer getQid() {
        return qid;
    }

    public void setQid(Integer qid) {
        this.qid = qid;
    }
    
    
    
    public String getQus() {
        return qus;
    }

    public void setQus(String qus) {
        this.qus = qus;
    }

    public String getqA() {
        return qA;
    }

    public void setqA(String qA) {
        this.qA = qA;
    }

    public String getqB() {
        return qB;
    }

    public void setqB(String qB) {
        this.qB = qB;
    }

    public String getqC() {
        return qC;
    }

    public void setqC(String qC) {
        this.qC = qC;
    }

    public String getqD() {
        return qD;
    }

    public void setqD(String qD) {
        this.qD = qD;
    }

    public String getOptradio() {
        return optradio;
    }

    public void setOptradio(String optradio) {
        this.optradio = optradio;
    }
    
}
