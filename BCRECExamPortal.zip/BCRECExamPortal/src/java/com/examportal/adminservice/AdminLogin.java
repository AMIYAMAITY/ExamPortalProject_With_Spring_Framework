
package com.examportal.adminservice;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 *
 * @author amiya
 */


public class AdminLogin 
{
    @NotEmpty(message = "Data Required")
    @Email(message = "Invalid Email ID")
    private String email;
    @NotEmpty(message = "Data Required")
    @Size(min = 5,max = 10,message = "Input size must be in between 5 to 10 character")
    private String pass;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   

    
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
}
