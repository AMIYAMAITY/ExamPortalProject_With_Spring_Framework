package com.examportal.adminservice;

import com.examportal.customvalidation.CusDate;
import com.examportal.customvalidation.CusTime;
import java.util.Date;
import org.hibernate.validator.constraints.NotEmpty;

/**
 *
 * @author amiya
 */
public class QuestionSetName {

    @NotEmpty(message = "Data Required")
    private String exam_set;
    @CusTime(message = "Invalid time")
    @NotEmpty(message = "Data Required")
    private String exam_stime;
    @CusTime(message = "Invalid time")
    @NotEmpty(message = "Data Required")
    private String exam_etime;
    @CusDate(message = "Invalid date")
    @NotEmpty(message = "Data Required")
    private String exam_date;

    private Integer id;
    private Integer qid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getQid() {
        return qid;
    }

    public void setQid(Integer qid) {
        this.qid = qid;
    }
    
    
    public String getExam_set() {
        return exam_set;
    }

    public void setExam_set(String exam_set) {
        this.exam_set = exam_set;
    }

    public String getExam_stime() {
        return exam_stime;
    }

    public void setExam_stime(String exam_stime) {
        this.exam_stime = exam_stime;
    }

    public String getExam_etime() {
        return exam_etime;
    }

    public void setExam_etime(String exam_etime) {
        this.exam_etime = exam_etime;
    }

    public String getExam_date() {
        return exam_date;
    }

    public void setExam_date(String exam_date) {
        this.exam_date = exam_date;
    }

}
