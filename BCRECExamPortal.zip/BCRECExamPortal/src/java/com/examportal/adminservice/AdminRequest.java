
package com.examportal.adminservice;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 *
 * @author amiya
 */


public class AdminRequest 
{
    @NotEmpty(message = "Data Required")
    @Size(min = 1,max = 20,message = "Input size must be 20 character")
    private String name;
    @NotEmpty(message = "Data Required")
    @Size(min = 10,max = 10,message = "Input size must be 10 character")
    private String cid;
    @NotEmpty(message = "Data Required")
    @Email(message = "Invalid Email ID")
    private String email;
    @NotEmpty(message = "Data Required")
    @Size(min = 5,max = 10,message = "Input size must be in between 5 to 10 character")
    private String pass1;
    @NotEmpty(message = "Data Required")
    @Size(min = 5,max = 10,message = "Input size must be in between 5 to 10 character")
    private String pass2;
    
    private int id;
    private int flag;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }


    public String getPass1() {
        return pass1;
    }

    public void setPass1(String pass1) {
        this.pass1 = pass1;
    }

    public String getPass2() {
        return pass2;
    }

    public void setPass2(String pass2) {
        this.pass2=pass2;
        if(!pass1.equals(this.pass2))
         this.pass1=null;
    }
    
}
