
package com.examportal.database;

import com.examportal.adminservice.QuestionSetName;
import java.util.Date;
import java.util.List;


public interface QuestionSetNameDAO 
{
    public Integer insert(Integer aid,String set_name,String stime,String etime,String date);
    public boolean delete(Integer aid,Integer qsid);
    public Integer getLastQid();
    public QuestionSetName getData(Integer qsid);
    public QuestionSetName getData(Integer qsid,Integer aid);
    public List<QuestionSetName> getDataById(Integer id);
    public boolean checkReferralCode(Integer qsid,String rc);
     public List<QuestionSetName> getDataToday(String date);
     public boolean updateQuestionSet(Integer qsid,String set,String stime,String etime,String date);
     public List<QuestionSetName> getAllData();
     
    
}
