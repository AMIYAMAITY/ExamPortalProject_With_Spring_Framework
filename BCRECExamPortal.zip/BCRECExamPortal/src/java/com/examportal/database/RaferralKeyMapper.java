
package com.examportal.database;

import com.examportal.adminservice.Referral;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class RaferralKeyMapper implements RowMapper<Referral>
{

    @Override
    public Referral mapRow(ResultSet rs, int i) throws SQLException {
      Referral r=new Referral();
      r.setQsid(rs.getInt("qsid"));
      r.setReferral_key(rs.getString("referral_key"));
      return r;
    }
    
}
