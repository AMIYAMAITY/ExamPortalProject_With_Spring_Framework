
package com.examportal.database;

import com.examportal.adminservice.Question;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author amiya
 */
public class QuestionJDBCTemplate implements QuestionDAO
{

     private DataSource dataSource;
private JdbcTemplate jdt;
 public QuestionJDBCTemplate()
    {
        DatabaseConfig dbc=new DatabaseConfig();
         this.dataSource = dbc.getDataSource();
          this.jdt = new JdbcTemplate(this.dataSource);
    }
   
    
    @Override
    public boolean insert(Integer sid, String qus, String ansA, String ansB, String ansC, String ansD, String corrAns) {
          String SQL = "insert into QUESTION(sid,qid,qus,qa,qb,qc,qd,corrans) VALUES(?,?,?,?,?,?,?,?)";
        try {
            jdt.update(SQL,sid,(getLastID() + 1),qus,ansA,ansB,ansC,ansD,corrAns);
            return true;
        } catch (Exception ex) {
            System.out.println("exception :"+ex);
            return false;
        }
    }

    @Override
    public int getLastID() {
          String SQL = "SELECT qid FROM QUESTION ORDER BY qid DESC LIMIT 1;";
        try {
            int qid = jdt.queryForInt(SQL);
            return qid;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public Integer countQuestion(Integer sid) {
          String SQL = "SELECT count(qid) FROM QUESTION where sid=?;";
        try {
            int count = jdt.queryForInt(SQL,sid);
            return count;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public List<Question> getQuestion(Integer sid) {
         String SQL="SELECT * FROM QUESTION WHERE sid=?";
         try
         {
        List<Question> qsn=jdt.query(SQL, new Object[]{sid},new QuestionRowMapper());
        return qsn;
         }
         catch(Exception ex)
         {
             return null;
         }
    }

    @Override
    public boolean questionDelete(Integer qid) {
        String SQL1="delete from ANSWER_SUBMIT where qid=?";
        String SQL2="delete from QUESTION where qid=?";
         try
         {
        int r1=jdt.update(SQL1, qid);
          int r2=jdt.update(SQL2, qid);
          if(r1!=0 && r2!=0)
        return true;
        else
        return false;
         }
         catch(Exception ex)
         {
             return false;
         }
    }
    
}
