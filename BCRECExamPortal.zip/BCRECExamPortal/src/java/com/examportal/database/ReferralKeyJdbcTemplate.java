/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.examportal.database;

import com.examportal.adminservice.Referral;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author amiya
 */
public class ReferralKeyJdbcTemplate implements ReferralKeyDAO{

    
     private DataSource dataSource;
private JdbcTemplate jdt;
    public ReferralKeyJdbcTemplate()
    {
          DatabaseConfig dbc=new DatabaseConfig();
         this.dataSource = dbc.getDataSource();
          this.jdt = new JdbcTemplate(this.dataSource);
    }
    @Override
    public Referral gerReferralKey(Integer qsid) {
         String SQL="SELECT * FROM REFERRAL WHERE qsid=?";
        try
        {
        Referral rk=jdt.queryForObject(SQL, new Object[]{qsid},new RaferralKeyMapper());
        return rk;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    @Override
    public boolean generateKey(Integer qsid, String key) {
          String SQL ="update REFERRAL set referral_key=? where qsid=?";
          try
        {
       int r=jdt.update(SQL,key,qsid);
       if(r!=0)
           return true;
       else
           return false;
        }
            catch(Exception ex)
        {
            return false;
        }
    }
    
    
}
