
package com.examportal.database;

import com.examportal.adminservice.Question;
import java.util.List;

/**
 *
 * @author amiya
 */
public interface QuestionDAO 
{
    public  boolean insert(Integer sid,String qus,String ansA,String ansB,String ansC,String ansD,String corrAns);
    public int getLastID();
    public Integer countQuestion(Integer sid);
    public List<Question> getQuestion(Integer sid);
    public boolean questionDelete(Integer qid);
   
}
