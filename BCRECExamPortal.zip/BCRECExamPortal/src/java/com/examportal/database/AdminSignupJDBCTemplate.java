package com.examportal.database;

import com.examportal.adminservice.AdminRequest2;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author amiya
 */
public class AdminSignupJDBCTemplate implements AdminSignupDAO {

    private DataSource dataSource;

    private JdbcTemplate jdt;

    public AdminSignupJDBCTemplate() {
        DatabaseConfig dbc = new DatabaseConfig();
        this.dataSource = dbc.getDataSource();
        this.jdt = new JdbcTemplate(this.dataSource);
    }

    @Override
    public boolean insert(String name, String email, String cid, String pass2,String otp) {
        String SQL = "insert into ADMIN_SIGNUP(id,name,email,cid,pass,otp,flag,verified) VALUES(?,?,?,?,?,?,?,?)";
        try {
            jdt.update(SQL, (getLastID() + 1), name, email, cid, pass2, otp,0, 0);
            return true;
        } catch (Exception ex) {
            return false;
        }

    }

    @Override
    public boolean updateFlag(int id, int flag) {
        String SQL = "update ADMIN_SIGNUP set flag=? where id=?";
        try {
            int r = jdt.update(SQL, flag, id);
            if (r != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public boolean updatePassword(int id, String pass) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getLastID() {

        String SQL = "SELECT id FROM ADMIN_SIGNUP ORDER BY id DESC LIMIT 1;";
        try {
            int id = jdt.queryForInt(SQL);
            return id;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public int checkLogin(String uname, String upass) {
        String SQL = "select id from ADMIN_SIGNUP where email=? and pass=?";
        try {
            int id = jdt.queryForInt(SQL, uname, upass);
            return id;
        } catch (Exception ex) {
            return 0;
        }
    }

    @Override
    public AdminRequest2 getData(Integer id) {
        String SQL = "select * from ADMIN_SIGNUP where id=?";
        try {
            AdminRequest2 admin2 = jdt.queryForObject(SQL, new Object[]{id}, new AdminRequest2Mapper());
            return admin2;
        } catch (Exception ex) {
            System.out.println("exception :" + ex);
            return null;
        }
    }

    @Override
    public List<AdminRequest2> getAdminsData(Integer flag) {
        String SQL = "SELECT * FROM ADMIN_SIGNUP WHERE flag=?";
        try {
            List<AdminRequest2> admins = jdt.query(SQL, new Object[]{flag}, new AdminRequest2Mapper());
            return admins;
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public boolean updateAdminProfile(Integer id, String email, String pass) {
        String SQL = "update ADMIN_SIGNUP set email=?,pass=? where id=?";
        try {
            int r = jdt.update(SQL, email, pass, id);
            if (r != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public AdminRequest2 getPassword(String email) {
        String SQL = "select * from ADMIN_SIGNUP where email=?";
        try {
            AdminRequest2 adr = jdt.queryForObject(SQL, new Object[]{email}, new AdminRequest2Mapper());
            return adr;
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public boolean checkVerified(String email) {
        String SQL = "SELECT verified FROM ADMIN_SIGNUP where email='"+ email+"'";
        try {
            int f = jdt.queryForInt(SQL);
            if (f != 0) {
                return true;
            } else {
                return false;
            }
        } catch (EmptyResultDataAccessException ex) {
            return false;
        }
    }
    
    @Override
    public boolean checkFlag(String email) {
        String SQL = "SELECT flag FROM ADMIN_SIGNUP where email='"+email+"'";
        try {
            int f = jdt.queryForInt(SQL);
            if (f != 0) {
                return true;
            } else {
                return false;
            }
        } catch (EmptyResultDataAccessException ex) {
            return false;
        }
    }

    @Override
    public boolean updateOTP(String email, String otp) {
        String SQL = "update ADMIN_SIGNUP set otp=? where email=?";
        try {
            int r = jdt.update(SQL, otp, email);
            if (r != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public Integer checkOTP(String email, String otp) {
        String SQL = "select id from ADMIN_SIGNUP where email=? and otp=?";
        String SQL2 = "update ADMIN_SIGNUP set verified=? where email=?";
        try {
            int id = jdt.queryForInt(SQL, email, otp);
            if (id != 0) {
                int r = jdt.update(SQL2, 1, email);
                if (r != 0) {
                    return id;
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        } catch (Exception ex) {
            return 0;
        }
    }

}
