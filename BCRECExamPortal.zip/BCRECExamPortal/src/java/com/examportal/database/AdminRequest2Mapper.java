
package com.examportal.database;

import com.examportal.adminservice.AdminRequest2;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class AdminRequest2Mapper implements RowMapper<AdminRequest2>
{

    @Override
    public AdminRequest2 mapRow(ResultSet rs, int i) throws SQLException {
        AdminRequest2 ad2=new AdminRequest2();
       ad2.setCid(rs.getString("cid"));
       ad2.setEmail(rs.getString("email"));
       ad2.setFlag(rs.getInt("flag"));
       ad2.setId(rs.getInt("id"));
       ad2.setName(rs.getString("name"));
       ad2.setPass2(rs.getString("pass"));
       return ad2;
    }
    
}
