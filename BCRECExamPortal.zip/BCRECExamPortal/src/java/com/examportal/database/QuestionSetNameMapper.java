
package com.examportal.database;

import com.examportal.adminservice.QuestionSetName;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class QuestionSetNameMapper implements RowMapper<QuestionSetName>
{

    @Override
    public QuestionSetName mapRow(ResultSet rs, int i) throws SQLException {
       QuestionSetName qsn=new QuestionSetName();
       qsn.setId(rs.getInt("id"));
       qsn.setQid(rs.getInt("qsid"));
       qsn.setExam_set(rs.getString("set_name"));
       qsn.setExam_stime(rs.getString("stime"));
       qsn.setExam_etime(rs.getString("etime"));
       qsn.setExam_date(rs.getString("date"));
       return qsn;
    }

  
    
}
