
package com.examportal.database;

import com.examportal.adminservice.Question;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class QuestionRowMapper implements RowMapper<Question>
{

    @Override
    public Question mapRow(ResultSet rs, int i) throws SQLException {
       Question q=new Question();
       q.setSid(rs.getInt("sid"));
       q.setQid(rs.getInt("qid"));
       q.setQus(rs.getString("qus"));
       q.setqA(rs.getString("qA"));
       q.setqB(rs.getString("qB"));
       q.setqC(rs.getString("qC"));
       q.setqD(rs.getString("qD"));
       q.setOptradio(rs.getString("corrans"));
       return q;
    }
    
}
