
package com.examportal.database;

import javax.sql.DataSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;




/**
 *
 * @author amiya
 */

@Configuration
public class DatabaseConfig 
{
           public DataSource getDataSource()
           {
               DriverManagerDataSource dmd=new DriverManagerDataSource();
               dmd.setDriverClassName("com.mysql.jdbc.Driver");
               dmd.setUrl("jdbc:mysql://localhost:3306/BCRECExamPortal");
               dmd.setUsername("root");
               dmd.setPassword("root");
               return dmd;
           }
}
