
package com.examportal.database;


import com.examportal.adminservice.AdminRequest2;
import java.util.List;

/**
 *
 * @author amiya
 */
public interface AdminSignupDAO 
{
    //public void setDataSource(DataSource dataSource);
    public boolean insert(String name,String email,String cid,String pass2,String otp);
    public boolean updateFlag(int id,int flag);
    public boolean updatePassword(int id,String pass);
    public int getLastID();
    public int checkLogin(String uname,String upass);
    public AdminRequest2 getData(Integer id);
    public List<AdminRequest2> getAdminsData(Integer flag);
    public boolean updateAdminProfile(Integer id,String email,String pass);
    public AdminRequest2 getPassword(String email);
    public boolean checkVerified(String email);
    public boolean updateOTP(String email,String otp);
    public Integer checkOTP(String email, String otp);
    public boolean checkFlag(String email);
}
