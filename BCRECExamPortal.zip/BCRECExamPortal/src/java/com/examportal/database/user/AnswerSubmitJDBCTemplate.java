
package com.examportal.database.user;

import com.examportal.database.DatabaseConfig;
import com.examportal.userservice.AnswerSubmit;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;




/**
 *
 * @author amiya
 */
public class AnswerSubmitJDBCTemplate implements AnswerSubmitDAO{
  private DataSource dataSource;
    private JdbcTemplate jdt;
    
    public AnswerSubmitJDBCTemplate()
    {
          DatabaseConfig dbc=new DatabaseConfig();
         this.dataSource = dbc.getDataSource();
          this.jdt = new JdbcTemplate(this.dataSource);
    }
    @Override
    public int getLastID() {
        
        String SQL = "SELECT ansid FROM ANSWER_SUBMIT ORDER BY ansid DESC LIMIT 1;";
        try {
            int id = jdt.queryForInt(SQL);
            return id;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public Boolean insert(Integer qsid, Integer uid, Integer qid, String answer) {
          String SQL = "insert into ANSWER_SUBMIT(ansid,qsid,uid,qid,answer) VALUES(?,?,?,?,?)";
        try {
            jdt.update(SQL, (getLastID() + 1), qsid, uid, qid, answer);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public boolean checkInsert(Integer qid) {
        String SQL="select ansid from ANSWER_SUBMIT where qid=?";
         try {
            jdt.queryForInt(SQL,qid);
            return true;
        } catch (EmptyResultDataAccessException ex) {
            return false;
        }
    }

    @Override
    public Boolean update(Integer qid, String answer) {
           String SQL = "update ANSWER_SUBMIT set answer=? where qid=?";
        try {
            jdt.update(SQL,answer,qid);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public int getMarks(int uid, int sid) {
         
        String SQL ="select count(q.qid) from QUESTION as q, ANSWER_SUBMIT as a where  q.qid=a.qid and q.corrans=a.answer and q.sid=? and a.uid=?";
        try {
            int t=jdt.queryForInt(SQL,sid,uid);
            return t;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public List<Integer> getSid(int uid) {
         String SQL="select distinct qsid from ANSWER_SUBMIT where uid="+uid;
         try
         {
            List<Integer> l=jdt.queryForList(SQL, Integer.class);
          
        return l;
         }
         catch(Exception ex)
         {
             return null;
         }
    }

    @Override
    public AnswerSubmit getData(int qid,int uid,int qsid) {
        String SQL="SELECT * FROM ANSWER_SUBMIT WHERE qid=? and uid=? and qsid=?";
         try
         {
        AnswerSubmit ans=jdt.queryForObject(SQL, new Object[]{qid,uid,qsid},new AnswerSubmitMapper());
        return ans;
         }
         catch(Exception ex)
         {
             return null;
         }
    }

    @Override
    public List<Integer> getUid(int sid) {
        String SQL="select distinct uid from ANSWER_SUBMIT where qsid="+sid;
         try
         {
            List<Integer> l=jdt.queryForList(SQL, Integer.class);
          
        return l;
         }
         catch(Exception ex)
         {
             return null;
         }
    }

    @Override
    public boolean isPresentSid(Integer qsid) {
         String SQL="select id from QUESTION_SET where qsid=?";
         try {
            jdt.queryForInt(SQL,qsid);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

   
    
}
