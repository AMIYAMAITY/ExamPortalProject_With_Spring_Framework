
package com.examportal.database.user;

import com.examportal.userservice.UserSignup;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class UserSignupMapper implements RowMapper<UserSignup>
{

    @Override
    public UserSignup mapRow(ResultSet rs, int i) throws SQLException {
       UserSignup us=new UserSignup();
       us.setUid(rs.getInt("uid"));
       us.setName(rs.getString("name"));
       us.setEmail(rs.getString("email"));
       us.setRoll(rs.getString("roll"));
       us.setGender(rs.getString("gender"));
       us.setPass(rs.getString("password"));
       return us;
    }
    
}
