
package com.examportal.database.user;

import com.examportal.userservice.UserSignup;
import java.util.List;

/**
 *
 * @author amiya
 */
public interface UserSignupDAO 
{
     public Boolean insert(String name,String email,String roll,String gender,String pass);
    public boolean updateFlag(int uid);
    public boolean updatePassword(int uid,String pass);
    public int getLastID();
    public int checkLogin(String uemail,String upass);
    public boolean checkverified(String uemail,String upass);
    public UserSignup getData(Integer uid);
    public List<UserSignup> getDataAll();
    public boolean updateProfile(Integer uid,String email,String pass);
    public boolean updateOTP(String email,String rString);
    public Integer checkOTP(String email,String otp);
    public UserSignup getPassword(String email);
}
