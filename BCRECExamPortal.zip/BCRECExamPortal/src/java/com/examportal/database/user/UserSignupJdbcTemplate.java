
package com.examportal.database.user;

import com.examportal.database.DatabaseConfig;
import com.examportal.userservice.UserSignup;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author amiya
 */
public class UserSignupJdbcTemplate implements UserSignupDAO
{

    final private DataSource dataSource;
    final private JdbcTemplate jdbcTemplate;
    public UserSignupJdbcTemplate()
    {
         DatabaseConfig dbc=new DatabaseConfig();
         this.dataSource = dbc.getDataSource();
          this.jdbcTemplate = new JdbcTemplate(this.dataSource);
    }
    
    @Override
    public Boolean insert(String name, String email, String roll, String gender, String pass) {
         String SQL = "insert into USER_SIGNUP(uid,name,email,roll,gender,password,verified) VALUES(?,?,?,?,?,?,0)";
        try {
            Integer uid=(getLastID() + 1);
            jdbcTemplate.update(SQL,uid, name, email, roll, gender, pass);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public boolean updateFlag(int uid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean updatePassword(int uid, String pass) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getLastID() {
         String SQL = "SELECT uid FROM USER_SIGNUP ORDER BY uid DESC LIMIT 1;";
        try {
            int id = jdbcTemplate.queryForInt(SQL);
            return id;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public int checkLogin(String uemail, String upass) {
         String SQL="select uid from USER_SIGNUP where email=? and password=? and verified=?";
        try {
            int uid = jdbcTemplate.queryForInt(SQL,uemail,upass,1);
            return uid;
        } catch (Exception ex) {
            return 0;
        }
    }

    @Override
    public UserSignup getData(Integer uid) {
          String SQL="SELECT * FROM USER_SIGNUP WHERE uid=?";
        try
        {
        UserSignup usnp=jdbcTemplate.queryForObject(SQL, new Object[]{uid},new UserSignupMapper());
        return usnp;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    @Override
    public List<UserSignup> getDataAll() {
         String SQL="SELECT * FROM USER_SIGNUP order by uid asc";
        try
        {
        List<UserSignup> students=jdbcTemplate.query(SQL,new UserSignupMapper());
        return students;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    @Override
    public boolean updateProfile(Integer uid,String email,String pass) {
         String SQL ="update USER_SIGNUP set email=?,password=? where uid=?";
          try
        {
       int r=jdbcTemplate.update(SQL,email,pass,uid);
       if(r!=0)
           return true;
       else
           return false;
        }
            catch(Exception ex)
        {
            return false;
        }
    }

    @Override
    public boolean updateOTP(String email, String rString) {
       String SQL ="update USER_SIGNUP set otp=? where email=?";
          try
        {
       int r=jdbcTemplate.update(SQL,rString,email);
       if(r!=0)
           return true;
       else
           return false;
        }
            catch(Exception ex)
        {
            return false;
        }
    }

    @Override
    public Integer checkOTP(String email, String otp) {
        String SQL="select uid from USER_SIGNUP where email=? and otp=?";
        String SQL2 ="update USER_SIGNUP set verified=? where email=?";
        try {
            int uid = jdbcTemplate.queryForInt(SQL,email,otp);
            if(uid!=0)
            {
            int r=jdbcTemplate.update(SQL2,1,email);
             if(r!=0)
            return uid;
             else
                 return 0;
            }else
                return 0;
        } catch (Exception ex) {
            return 0;
        }
    }

    @Override
    public boolean checkverified(String uemail, String upass) {
          String SQL="select verified from USER_SIGNUP where email=? and password=?";
        try {
            int vf = jdbcTemplate.queryForInt(SQL,uemail,upass);
            if(vf==0)
            return true;
            else
                return false;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public UserSignup getPassword(String email) {
       String SQL="select * from USER_SIGNUP where email=? and verified=?";
        try
        {
        UserSignup usnp=jdbcTemplate.queryForObject(SQL, new Object[]{email,1},new UserSignupMapper());
        return usnp;
        }
        catch(Exception ex)
        {
            return null;
        }
    }
    
}
