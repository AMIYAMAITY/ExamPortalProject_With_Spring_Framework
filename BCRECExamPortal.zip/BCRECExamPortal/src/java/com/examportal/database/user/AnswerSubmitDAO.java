
package com.examportal.database.user;

import com.examportal.userservice.AnswerSubmit;
import java.util.List;

/**
 *
 * @author amiya
 */
public interface AnswerSubmitDAO 
{
        public int getLastID();
        public Boolean insert(Integer qsid,Integer uid,Integer qid,String answer);
        public Boolean update(Integer qid,String answer);
        public boolean checkInsert(Integer qid);
        public int getMarks(int uid,int sid);
        public List<Integer> getSid(int uid);
        public AnswerSubmit getData(int qid,int uid,int qsid);
        public List<Integer> getUid(int sid);
        public boolean isPresentSid(Integer qsid);
}
