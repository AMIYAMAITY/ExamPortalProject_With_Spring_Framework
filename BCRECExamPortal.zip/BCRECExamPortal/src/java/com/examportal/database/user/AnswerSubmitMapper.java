
package com.examportal.database.user;

import com.examportal.userservice.AnswerSubmit;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class AnswerSubmitMapper implements RowMapper<AnswerSubmit>
{

    @Override
    public AnswerSubmit mapRow(ResultSet rs, int i) throws SQLException {
     AnswerSubmit as=new AnswerSubmit();
     as.setAnsid(rs.getInt("ansid"));
     as.setQsid(rs.getInt("qsid"));
     as.setUid(rs.getInt("uid"));
     as.setQid(rs.getInt("qid"));
     as.setAnswer(rs.getString("answer"));
     return as;
    }
    
}
