
package com.examportal.database;

import com.examportal.adminservice.AdminRequest;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author amiya
 */
public class AdminSignupMapper implements RowMapper<AdminRequest>
{

    @Override
    public AdminRequest mapRow(ResultSet rs, int i) throws SQLException {
       AdminRequest adrq=new AdminRequest();
       
       adrq.setCid(rs.getString("cid"));
       adrq.setEmail(rs.getString("email"));
       adrq.setFlag(rs.getInt("flag"));
       adrq.setId(rs.getInt("id"));
       adrq.setName(rs.getString("name"));
       adrq.setPass2(rs.getString("pass2"));
       
       return adrq;
    }
    
}
