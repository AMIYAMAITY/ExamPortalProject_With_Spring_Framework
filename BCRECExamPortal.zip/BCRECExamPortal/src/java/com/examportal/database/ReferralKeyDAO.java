
package com.examportal.database;

import com.examportal.adminservice.Referral;

/**
 *
 * @author amiya
 */
public interface ReferralKeyDAO 
{
    public Referral gerReferralKey(Integer qsid);
    public boolean generateKey(Integer qsid,String key);
}
