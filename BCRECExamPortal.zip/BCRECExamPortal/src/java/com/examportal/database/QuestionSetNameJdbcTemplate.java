
package com.examportal.database;

import com.examportal.adminservice.QuestionSetName;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import com.examportal.service.RandomString;
import java.util.List;



/**
 *
 * @author amiya
 */
public class QuestionSetNameJdbcTemplate implements QuestionSetNameDAO
{

    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;
    
    public QuestionSetNameJdbcTemplate()
    {
         DatabaseConfig dbc=new DatabaseConfig();
         this.dataSource = dbc.getDataSource();
          this.jdbcTemplate = new JdbcTemplate(this.dataSource);
    }

    @Override
    public Integer insert(Integer aid,String set_name, String stime, String etime, String date) {
       String SQL = "insert into QUESTION_SET(id,qsid,set_name,stime,etime,date) VALUES(?,?,?,?,?,?)";
       String SQL2="insert into REFERRAL(qsid,referral_key) values(?,?)";
        try {
            Integer qsid=(getLastQid() + 1);
            jdbcTemplate.update(SQL,aid, qsid, set_name, stime, etime, date);
            jdbcTemplate.update(SQL2,qsid,RandomString.generate(5));
            return qsid;
        } catch (Exception ex) {
            return null;
        }
        
    }

    @Override
    public boolean delete(Integer aid, Integer qsid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }



    @Override
    public Integer getLastQid() {
         String SQL = "SELECT qsid FROM QUESTION_SET ORDER BY id DESC LIMIT 1;";
        try {
            int id = jdbcTemplate.queryForInt(SQL);
            return id;
        } catch (EmptyResultDataAccessException ex) {
            return 0;
        }
    }

    @Override
    public QuestionSetName getData(Integer qsid) {
        String SQL="SELECT * FROM QUESTION_SET WHERE qsid=? order by date asc";
        try
        {
        QuestionSetName qsn=jdbcTemplate.queryForObject(SQL, new Object[]{qsid},new QuestionSetNameMapper());
        return qsn;
        }
        catch(Exception ex)
        {
            return null;
        }
    }
    
    @Override
    public QuestionSetName getData(Integer qsid,Integer aid) {
        String SQL="SELECT * FROM QUESTION_SET WHERE qsid=? and id=? order by date asc";
        try
        {
        QuestionSetName qsn=jdbcTemplate.queryForObject(SQL, new Object[]{qsid,aid},new QuestionSetNameMapper());
        return qsn;
        }
        catch(Exception ex)
        {
            return null;
        }
    }
    
    
    
    
    @Override
    public List<QuestionSetName> getDataToday(String d) {
        String SQL="SELECT * FROM QUESTION_SET WHERE date=?";
        try
        {
        List<QuestionSetName> qsn=jdbcTemplate.query(SQL, new Object[]{d},new QuestionSetNameMapper());
        return qsn;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    @Override
    public boolean checkReferralCode(Integer qsid, String rc) {
         String SQL="SELECT qsid FROM REFERRAL WHERE qsid=? and referral_key=?";
        try
        {
        jdbcTemplate.queryForInt(SQL,qsid,rc);
        return true;
        }
        catch(Exception ex)
        {
            return false;
        }
    }

    @Override
    public List<QuestionSetName> getDataById(Integer id) {
           String SQL="SELECT * FROM QUESTION_SET WHERE id=?";
        try
        {
        List<QuestionSetName> qsn=jdbcTemplate.query(SQL, new Object[]{id},new QuestionSetNameMapper());
        return qsn;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

    @Override
    public boolean updateQuestionSet(Integer qsid, String set, String stime, String etime, String date) {
       String SQL ="update QUESTION_SET set set_name=?,stime=?,etime=?,date=? where qsid=?";
          try
        {
       int r=jdbcTemplate.update(SQL, set,stime,etime,date,qsid);
       if(r!=0)
           return true;
       else
           return false;
        }
            catch(Exception ex)
        {
            return false;
        }
       
    }

    @Override
    public List<QuestionSetName> getAllData() {
        String SQL="SELECT * FROM QUESTION_SET order by date asc";
        try
        {
        List<QuestionSetName> qsn=jdbcTemplate.query(SQL,new QuestionSetNameMapper());
        return qsn;
        }
        catch(Exception ex)
        {
            return null;
        }
    }

   
}
