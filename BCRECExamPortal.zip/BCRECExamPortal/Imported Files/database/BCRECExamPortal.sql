-- MySQL dump 10.13  Distrib 5.7.22, for Linux (x86_64)
--
-- Host: localhost    Database: BCRECExamPortal
-- ------------------------------------------------------
-- Server version	5.7.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ADMIN_SIGNUP`
--

DROP TABLE IF EXISTS `ADMIN_SIGNUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ADMIN_SIGNUP` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `cid` varchar(20) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0',
  `otp` varchar(10) NOT NULL,
  `verified` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `cid` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ADMIN_SIGNUP`
--

LOCK TABLES `ADMIN_SIGNUP` WRITE;
/*!40000 ALTER TABLE `ADMIN_SIGNUP` DISABLE KEYS */;
INSERT INTO `ADMIN_SIGNUP` VALUES (1,'Ramanath Mandal','ramanathmandal784@gmail.com','BCREC12345','dlQC/4EQcNMFhkHQdARWmw==',1,'',0);
/*!40000 ALTER TABLE `ADMIN_SIGNUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ANSWER_SUBMIT`
--

DROP TABLE IF EXISTS `ANSWER_SUBMIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ANSWER_SUBMIT` (
  `ansid` int(11) NOT NULL,
  `qsid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `answer` varchar(3) NOT NULL,
  PRIMARY KEY (`ansid`),
  UNIQUE KEY `qid` (`qid`),
  KEY `qsid` (`qsid`),
  KEY `uid` (`uid`),
  CONSTRAINT `ANSWER_SUBMIT_ibfk_1` FOREIGN KEY (`qsid`) REFERENCES `QUESTION_SET` (`qsid`),
  CONSTRAINT `ANSWER_SUBMIT_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `USER_SIGNUP` (`uid`),
  CONSTRAINT `ANSWER_SUBMIT_ibfk_3` FOREIGN KEY (`qid`) REFERENCES `QUESTION` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ANSWER_SUBMIT`
--

LOCK TABLES `ANSWER_SUBMIT` WRITE;
/*!40000 ALTER TABLE `ANSWER_SUBMIT` DISABLE KEYS */;
INSERT INTO `ANSWER_SUBMIT` VALUES (1,1,1,1,'D'),(2,1,1,5,'A'),(3,1,1,6,'B'),(4,1,1,2,'D'),(5,1,1,3,'B'),(6,1,2,4,'A');
/*!40000 ALTER TABLE `ANSWER_SUBMIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUESTION`
--

DROP TABLE IF EXISTS `QUESTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUESTION` (
  `sid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `qus` varchar(50353) DEFAULT NULL,
  `qa` varchar(800) NOT NULL,
  `qb` varchar(800) NOT NULL,
  `qc` varchar(800) NOT NULL,
  `qd` varchar(800) NOT NULL,
  `corrans` varchar(5) NOT NULL,
  PRIMARY KEY (`qid`),
  KEY `sid` (`sid`),
  CONSTRAINT `QUESTION_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `QUESTION_SET` (`qsid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUESTION`
--

LOCK TABLES `QUESTION` WRITE;
/*!40000 ALTER TABLE `QUESTION` DISABLE KEYS */;
INSERT INTO `QUESTION` VALUES (1,1,'	\nA distributed database has which of the following advantages over a centralized database?','Software cost','Software complexity','Slow Response','Modular growth','D'),(1,2,'An autonomous homogeneous environment is which of the following?','The same DBMS is at each node and each DBMS works independently.','The same DBMS is at each node and a central DBMS coordinates database access.','A different DBMS is at each node and each DBMS works independently.','A different DBMS is at each node and a central DBMS coordinates database access.','A'),(1,3,'A transaction manager is which of the following?','Maintains a log of transactions','Maintains before and after database images','Maintains appropriate concurrency control','All of the above.','D'),(1,4,'Location transparency allows for which of the following?','Users to treat the data as if it is at one location','Programmers to treat the data as if it is at one location','Managers to treat the data as if it is at one location','All of the above.','D'),(1,5,'A heterogeneous distributed database is which of the following?','The same DBMS is used at each location and data are not distributed across all nodes.','The same DBMS is used at each location and data are distributed across all nodes.','A different DBMS is used at each location and data are not distributed across all nodes.','A different DBMS is used at each location and data are distributed across all nodes.','D'),(1,6,'rdtfgdffffd','futyudyut','ygyty','ytyt','ytyty','B');
/*!40000 ALTER TABLE `QUESTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QUESTION_SET`
--

DROP TABLE IF EXISTS `QUESTION_SET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QUESTION_SET` (
  `id` int(11) NOT NULL,
  `qsid` int(11) NOT NULL,
  `set_name` varchar(500) NOT NULL,
  `stime` varchar(5) NOT NULL,
  `etime` varchar(5) NOT NULL,
  `date` varchar(15) NOT NULL,
  PRIMARY KEY (`qsid`),
  KEY `id` (`id`),
  CONSTRAINT `QUESTION_SET_ibfk_1` FOREIGN KEY (`id`) REFERENCES `ADMIN_SIGNUP` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QUESTION_SET`
--

LOCK TABLES `QUESTION_SET` WRITE;
/*!40000 ALTER TABLE `QUESTION_SET` DISABLE KEYS */;
INSERT INTO `QUESTION_SET` VALUES (1,1,'Distributed Database Management System','01:00','02:00','2018-11-28'),(1,2,'SET-I','10:00','12:00','2018-11-24');
/*!40000 ALTER TABLE `QUESTION_SET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REFERRAL`
--

DROP TABLE IF EXISTS `REFERRAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REFERRAL` (
  `qsid` int(11) NOT NULL,
  `referral_key` varchar(10) NOT NULL,
  UNIQUE KEY `qsid` (`qsid`),
  CONSTRAINT `REFERRAL_ibfk_1` FOREIGN KEY (`qsid`) REFERENCES `QUESTION_SET` (`qsid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REFERRAL`
--

LOCK TABLES `REFERRAL` WRITE;
/*!40000 ALTER TABLE `REFERRAL` DISABLE KEYS */;
INSERT INTO `REFERRAL` VALUES (1,'Djx25'),(2,'Onw-j');
/*!40000 ALTER TABLE `REFERRAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SUPER_ADMIN`
--

DROP TABLE IF EXISTS `SUPER_ADMIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SUPER_ADMIN` (
  `id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SUPER_ADMIN`
--

LOCK TABLES `SUPER_ADMIN` WRITE;
/*!40000 ALTER TABLE `SUPER_ADMIN` DISABLE KEYS */;
INSERT INTO `SUPER_ADMIN` VALUES (1,'administrator','amiyamaity23@gmail.com','dlQC/4EQcNMFhkHQdARWmw==');
/*!40000 ALTER TABLE `SUPER_ADMIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_SIGNUP`
--

DROP TABLE IF EXISTS `USER_SIGNUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_SIGNUP` (
  `uid` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `roll` varchar(15) NOT NULL,
  `gender` varchar(9) NOT NULL,
  `password` varchar(130) NOT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `verified` varchar(10) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `roll` (`roll`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_SIGNUP`
--

LOCK TABLES `USER_SIGNUP` WRITE;
/*!40000 ALTER TABLE `USER_SIGNUP` DISABLE KEYS */;
INSERT INTO `USER_SIGNUP` VALUES (1,'Amiya Maity','amiyamaity23@gmail.com','1234567890','Male','dlQC/4EQcNMFhkHQdARWmw==',NULL,'1'),(2,'Subrata Das','subratadasbca@gmail.com','1234567891','Male','dlQC/4EQcNMFhkHQdARWmw==','utY-1','1'),(3,'Arup Panda','aruppanda15@gmail.com','0123456789','Male','dlQC/4EQcNMFhkHQdARWmw==','zj53T','0');
/*!40000 ALTER TABLE `USER_SIGNUP` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-02  0:31:40
