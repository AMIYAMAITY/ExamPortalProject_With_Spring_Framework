
var x = document.getElementById("adsp");
x.style.display = "none";


function showHideAdminPanel()
{
    var x = document.getElementById("adsp");
    var y = document.getElementById("adlg");
    if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "none";
    } else {
        x.style.display = "block";
    }
}

function goBackAdminLogin()
{
    var x = document.getElementById("adsp");
    var y = document.getElementById("adlg");
    if (x.style.display === "block") {
        x.style.display = "none";
        y.style.display = "block";
    } else {
        y.style.display = "block";
    }
}

function showHideQ_set()
{
    var x = document.getElementById("nq");
    var y = document.getElementById("q_set");
    x.style.display = "none";
    y.style.display = "block";

}

function showHideN_set()
{
    var x = document.getElementById("nq");
    var y = document.getElementById("q_set");
    x.style.display = "block";
    y.style.display = "none";
}
